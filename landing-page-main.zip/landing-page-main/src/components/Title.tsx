// This is for future use; it's used for subpages title
// right now we don't have any subpage.
function Title() {
  return <></>;
}

export default Title;
